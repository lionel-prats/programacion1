lista_puntajes = [
    { "nro": "1.", "nombre": "     CelEstE", "puntaje": 100 },
    { "nro": "2.", "nombre": "IvaN     ", "puntaje": 90 },
    { "nro": "3.", "nombre": "SOFIA GUTIERREZ", "puntaje": 80 },
    { "nro": "4.", "nombre": "Fran", "puntaje": 70 },
    { "nro": "5.", "nombre": "FACU        ", "puntaje": 60 },
    { "nro": "6.", "nombre": "        ALEJO    ", "puntaje": 50 },
    { "nro": "7.", "nombre": "mario", "puntaje": 40 }
]


