def formatear_puntaje(puntaje: str) -> str:
    return puntaje

def formatear_nombre_jugador(nombre: str) -> str:
    return nombre